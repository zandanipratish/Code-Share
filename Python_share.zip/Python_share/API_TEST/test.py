from flask import Flask, request , jsonify

app = Flask(__name__)

@app.route('/xyz' , methods = ['GET','POST'])
def test():
    if(request.method == 'POST'):
        a = request.json['num1']
        b = request.json['num2']
        result = a+b
        return jsonify(str(result))

@app.route('/abc/prats' , methods = ['POST'])
def test1():
    if(request.method == 'POST'):
        a = request.json['num3']
        b = request.json['num4']
        result = a+b
        return jsonify(str(result))

@app.route('/abc/prats/zandani' , methods = ['POST'])
def test2():
    if(request.method == 'POST'):
        a = request.json['num4']
        b = request.json['num5']
        result = a+b
        return jsonify(str(result))

@app.route('/abc/test' , methods = ['POST'])
def tes3():
    if(request.method == 'POST'):
        a = request.json['str1']
        b = request.json['str2']
        result = a+b
        return jsonify(str(result))



if __name__ == '__main__':
    app.run()