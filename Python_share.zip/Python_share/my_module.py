data = {"name":"ineuron",
"course" : ["data science","blockchain","drone","robotics","cloud"],
"greeting":"greeting from ineuron"
}

def get_course():
    return data['course']
    
def get_greeting():
    return data['greeting']