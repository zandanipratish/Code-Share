def l_append(l,*args):
    try:
        if type(l) == list:
            for i in args:
                l = l+[i]

    except Exception as e:
        print(e)
    else:
        return l