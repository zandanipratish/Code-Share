from pkg1 import pkg1test3
pkg1test3.test1()
