def test1():
    print("This is my function inside package1 test3 module")

test1()