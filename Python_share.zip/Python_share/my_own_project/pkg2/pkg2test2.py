from pkg1 import pkg1test3
import test
pkg1test3.test1()
course = test.get_course()
print(course)