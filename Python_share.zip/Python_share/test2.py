def test(a,b):
    return a+b
    
def test1(b,c):
    """This is my test1 function"""
    return b*c

def test3(b,n):
    return b/n

def test4():
    print("This is my first module")    